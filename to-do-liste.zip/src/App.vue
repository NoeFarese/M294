<script setup>
import { ref, computed } from 'vue'

const tasks = ref([
  { text: 'Rasen mähen',        done: false, high_priority: false },
  { text: 'Französisch lernen', done: true, high_priority: true },
  { text: 'Einkaufen',          done: false, high_priority: true },
  { text: 'Abfall rausbringen', done: false, high_priority: true },
])

const taskname = ref('')
const highPriority = ref(false)

const doneTasks = computed(() =>{
  let done = 0;
   for (let i = 0; i < tasks.value.length; i++) {
    if(tasks.value[i].done == true){
      done++;
    } 
  }
  return done
})

const sortedTasks = computed(() => {
  return tasks.value.sort((b, a) => Number(a.high_priority) - Number(b.high_priority))
})

const allTasks = computed(() => {
  return tasks.value.length;
})

function addTask(){
  tasks.value.push({ text: taskname.value, done: false, high_priority: highPriority.value })
  taskname.value = ''
  highPriority.value = false
}

function deleteTask(index){
  tasks.value.splice(index, 1);
}
</script>

<template>
  <div class="container">
    <h2>
      Aufgabenliste
    </h2>
    
    <p>
      {{ doneTasks }} von {{ allTasks }} Tasks sind erledigt.
    </p>

    <div class="form-group">
      <label for="task">Neuer Task</label>
      <input class="form-control" id="task" type="text" v-model="taskname">
    </div>

    <label for="prio">
      <input id="prio" type="checkbox" @click="highPriority = true" v-model="highPriority">
      Hohe Priorität
    </label>

    <div class="form-actions">
      <button @click="addTask()">
        Task hinzufügen
      </button>
    </div>
    
    <ul>
      <li v-for="(task, index) in sortedTasks" :key="index" :class="{ 'is-done': task.done, 'high-priority': task.high_priority }">
        <input type="checkbox" v-model="task.done">
        {{ task.text }}
        <button @click="deleteTask(index)">Löschen</button>
      </li>
    </ul>
  </div>
</template>

<style>
  .is-done {
    text-decoration: line-through;
  }
  
  .high-priority {
    font-weight: bold;
    color: red;
  }
  
  .form-group {
    display: block;
  }
  
  .form-group label {
    display: block;
    margin-bottom: 2px;
  }
  
  .form-control {
    width: 100%;
    padding: 2px 5px;
    height: 32px;
    margin-bottom: 5px;
  }
  
  .form-actions {
    display: block;
    margin-top: 1rem;
    margin-bottom: 2rem;
  }
  
  .container {
    margin: 20px auto;
    max-width: 400px;
    width: 100%;
  }
</style>