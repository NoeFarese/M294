<script setup>
import { ref, computed } from 'vue'

const number1 = ref(1)
const number2 = ref(2)
const number3 = ref(3)
const result = computed(() => {
  return number1.value + number2.value + number3.value
})
</script>

<template>
  <input type="number" v-model="number1" />
  <input type="number" v-model="number2" />
  <input type="number" v-model="number3" />
  <div>Summe: {{ result }}</div>
</template>
