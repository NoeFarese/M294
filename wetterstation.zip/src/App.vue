<script setup>
import { ref, computed } from 'vue'

const temperaturCelsius = ref(10)
const istUnterGefrierpunkt = ref('nein')

const fahrenheit = computed(() => {
    return (temperaturCelsius.value * 1.8) + 32
})

const kelvin = computed(() => {
  return temperaturCelsius.value + 273.15;
})

function change(number){
  temperaturCelsius.value += number

  if(temperaturCelsius.value < 0){
    istUnterGefrierpunkt.value = 'ja'
  } else {
    istUnterGefrierpunkt.value = 'nein'
  }
}
</script>

<template>
  <h1>Wetterstation</h1>
  <p><b>Temperatur in Celsius:</b> {{ temperaturCelsius }} °C</p>
  <p><b>Temperatur in Fahrenheit:</b> {{ fahrenheit }} °F</p>
  <p><b>Temperatur in Kelvin:</b> {{ kelvin }} °K</p>
  <p><b>Gefrierpunkt unterschritten:</b> {{ istUnterGefrierpunkt }}</p>

  <button @click="change(-5)">Es wird kälter</button>
  <button @click="change(5)">Es wird wärmer</button>
</template>
