<script setup>
  import { defineProps, computed } from 'vue';

  const props = defineProps({
    title: String,
    teaser: String,
    image: String,
    numberOfWords: Number
  })

  const title = computed(() => props.title);
  const teaser = computed(() => props.teaser);
  const image = computed(() => props.image);
  const numberOfWords = computed(() => props.numberOfWords);

  const calculateReadTime = () => {
    const wordsPerMinute = 300;
    const readTimeMinutes = Math.ceil(numberOfWords.value / wordsPerMinute);
    return readTimeMinutes;
  };
</script>

<template>
  <div class="newsfeed__item">
    <div class="newsfeed__image">
      <img :src="image" alt="News Image" />
    </div>
    <div class="newsfeed__text">
      <h2 class="newsfeed__heading">
        {{ title }}
      </h2>  
      <p class="newsfeed__teaser">
        {{ teaser }} 
      </p>  
      <p class="newsfeed__meta">
        {{ numberOfWords }} words, read time: {{ calculateReadTime() }} min
      </p>
    </div>
  </div>
</template>

<style>
  .newsfeed__item {
    display: grid;
    grid-template-columns: 200px auto;
  }

  .newsfeed__item + .newsfeed__item {
    border-top: 1px solid hsla(0,0%,100%,.05);
  }

  .newsfeed__image img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  .newsfeed__text {
    padding: 20px;
  }
  
  .newsfeed__heading {
    font-size: 18px;
    margin: 10px 0;
  }
  
  .newsfeed__teaser {
    font-size: 15px;
    line-height: 1.25;
  }
  
  .newsfeed__meta {
    font-size: 15px;
    line-height: 1.25;
    color: rgba(255, 255, 255, .6);
  }
</style>
