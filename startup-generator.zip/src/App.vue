<script setup>
import { ref } from 'vue'

const randomStartupName = ref('')

function generate(){
  const prefix = prefixes[Math.floor(Math.random() * prefixes.length)]
  const suffix = suffixes[Math.floor(Math.random() * suffixes.length)]
  this.randomStartupName = prefix+suffix
}

const prefixes = [
  'Hype',
  'Biz',
  'Lolz',
  'Rofl',
  'Galaxy',
  'Biz',
  'Fan',
  'Buzz',
  'Real',
  'Solid',
  'Inter',
  'Active',
  'Swoosh',
]

const suffixes = [
  'park',
  'span',
  'cloud',
  'loop',
  'verse',
  'layer',
  'er',
  'r',
  'dot',
  'dock',
  'space',
  'yard',
  'scale',
  'signal',
  'press',
  'ware',
  'port',
]
</script>

<template>
  <h1>Dein Startup heisst</h1>
  <input v-model="randomStartupName" disabled type="text">
  <br/>
  <button @click="generate()">Namen generieren</button>
</template>

<style>
 input {
  background-color: lightgrey;
  border: none;
  border-radius: 4px;
  color: black;
  padding: 20px;
  text-align: center;
  margin-bottom: 20px;
 }
</style>
