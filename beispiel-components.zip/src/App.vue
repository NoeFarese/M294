<script setup>
import { ref } from 'vue'
import Hello from './Hello.vue';

const name = ref('M294')
</script>

<template>
  <Hello :name="name" />
  <input type="checkbox" :checked="true"/>
</template>
