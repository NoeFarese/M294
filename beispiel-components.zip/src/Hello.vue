<script setup>
import { computed } from 'vue';

  const props = defineProps({
    name: String
  })

  const text = computed(() => {
    return "Hello " + props.name
  })
</script>

<template>
  <h1>{{ text }}!</h1>
</template>
